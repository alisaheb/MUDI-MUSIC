<?php

namespace Google\Drive;

class Drive {


	 protected function getStartTime()
    {
        if (defined('LARAVEL_START'))
        {
            return LARAVEL_START;
        }

        return microtime(true);
    }

}