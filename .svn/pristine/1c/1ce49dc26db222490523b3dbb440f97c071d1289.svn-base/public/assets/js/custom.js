var former_add_calss = function(){
	$( ".control-label" ).addClass( "col-md-4" );
	$( ".control-label" ).addClass( "col-md-4" )
} 