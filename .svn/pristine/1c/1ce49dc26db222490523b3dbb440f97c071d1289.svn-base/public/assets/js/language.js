/**
 * Created by ALi on 09/10/2015.
 */
$(document).ready(function() {
    $("#language_changesfuck").on('click', function () {
        alert("working");
    });

});

