<?php namespace Ali;

class AnvilHeavy implements AnvilInterface {

    public function drop()
    {
        return "ouch!";
    }

}