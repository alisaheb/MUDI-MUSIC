<?php namespace ali;

interface AnvilInterface {

    public function drop();

}