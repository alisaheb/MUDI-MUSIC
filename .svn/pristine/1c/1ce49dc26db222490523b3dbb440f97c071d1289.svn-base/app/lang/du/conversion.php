<?php
/*Dutch conversion*/
return array(
    /*
     *
     * button for all*/
    'save'=>'Sparen',
    'reset'=>'Resetten',
    'upload'=>'Uploaden',
    'edit'=>'Bewerk',
    'delete'=>'Verwijderen',
    'update'=>'Bijwerken',
    /*
     *
     * get score page*/
    'get_score'=>'Krijgen Scores',
    'album'=>'Albums',
    'serial'=>'Serie-',
    'album_name'=>'Album Naam',
    'action'=>'Acties',
    'view'=>'Vitzicht',
    'purchased'=>'Gekochte',
    'purchase'=>'Aankoop',
    /*
     *
     * get license page*/
    'license'=>'Licentie',
    'get_license'=>'Krijgen Licentie',
    'current_license'=>'Huidige Licentie',
    'click_here_for_license_information'=>'klik hier voor licentie-informatie',
    'your_license_type'=>'Uw Licentie Soort',
    'your_band_id'=>'Je Band Id',
    'your_band_key'=>'Je Band Sleutel',
    'band_information'=>'Band Informatie',
    'lead_name'=>'Lead Naam',
    'band_name'=>'Band Naam',
    'license_type'=>'Soort Licentie',
    'validity'=>'Deugdelijkheid',
    'update_availability'=>'Beschikbaarheid Bijwerken',
    'free_practice_total'=>'Vrije Training In Totaal',
    'device_allow'=>'Apparaat Toestaan',
    /*
     *
     * album score list
     * */
    'album_score'=>'Album Scores',
    'scores'=>'Scores',
    'track_name'=>'Spoor Naam',
    /*
     *
     * manage band profile*/
    'overview'=>'Overzicht',
    'account_setting'=>'Account Instellen',
    'change_pass'=>'Verander Wachtwoord',
    'help'=>'Helpen',
    /*
     *
     * change band logo*/
    'manage_profile'=>'Beheren Profiel',
    'change_band_logo'=>'Change Band Logo',
    'change_logo'=>'Change Logo',
    'band_logo'=>'Band Logo',
    /*
     *
     * change band pass*/
    'current_password'=>'Huidig Wachtwoord',
    'new_password'=>'Nieuw Wachtwoord',
    'retype_password'=>'Geef Nogmaals Het Wachtwoord',
    /*
     *
     * upload score*/
    'upload_score'=>'Uploaden Scores',
    'track_file'=>'Track File',
    'add_detail'=>'Toevoegen Detail',
    /*
     * all albums*/
    'all_album'=>'Alle Albums',
    /*
     *
     * update album*/
    'update_album'=>'Bijwerken Album',
    'update_score'=>'Bijwerken Partituur',
    /*
     *
     * change publisher logo nad name*/
    'publisher_logo'=>'Uitgever Logo',
    'name'=>'Namm',
    /*
     *
     * publisher dashboard*/
    'dashboard'=>'Dashboard',
    'number_of_score'=>'Aantal Score',
    'number_of_album'=>'Aantal Album',
    'sales_album'=>'Sales Album',
    'album_user'=>'Album Gebruiker',
    'latest_score'=>'Laatste Score',
    'latest_album'=>'Laatste Album',
    'latest_sales_score'=>'Laatste Verkoop Score',
    'latest_sales_report'=>'Laatste Sales Report',
    'score_title'=>'Score Titel',
    'number_of_time_sales'=>'Aantal Time Sales',
    'new_score'=>'Nieuw Score',
    'new_album'=>'Nieuw Album',
    'new_sales_score'=>'Nieuw Verkoop Score',
    'view_all_score'=>'Alles Score',
    'view_all_album'=>'Alles Album',
    'view_all_sales_score'=>'Alles Sales Score',
    'view_all_sales_report'=>'Alles Sales Report',
);