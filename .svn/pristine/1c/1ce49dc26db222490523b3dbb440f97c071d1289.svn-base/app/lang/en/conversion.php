<?php
/*english conversion*/
return array(
    /*
     *
     * button for all*/
    'save'=>'Save',
    'reset'=>'Reset',
    'upload'=>'Upload',
    'edit'=>'Edit',
    'delete'=>'Delete',
    'update'=>'Update',

    /*
     *
     * get score page*/
    'get_score'=>'Get Scores',
    'album'=>'Albums',
    'serial'=>'Serial',
    'album_name'=>'Album Name',
    'action'=>'Actions',
    'view'=>'View',
    'purchased'=>'Purchased',
    'purchase'=>'Purchase',

    /*
     *
     * get license page*/

    'license'=>'License',
    'get_license'=>'Get License',
    'current_license'=>'Current License',
    'click_here_for_license_information'=>'Click here for license information',
    'your_license_type'=>'Your License Type',
    'your_band_id'=>'Your Band Id',
    'your_band_key'=>'Your Band Key',
    'band_information'=>'Band Information',
    'lead_name'=>'Lead Name',
    'band_name'=>'Band Name',
    'license_type'=>'License Type',
    'validity'=>'Validity',
    'update_availability'=>'Update Availability',
    'free_practice_total'=>'Free Practice Total',
    'device_allow'=>'Device Allow',
    /*
     *
     * album score list
     * */
    'album_score'=>'Album Scores',
    'scores'=>'Scores',
    'track_name'=>'Track Name',
    /*
     *
     * manage band profile*/
    'overview'=>'Overview',
    'account_setting'=>'Account Setting',
    'change_pass'=>'Change Password',
    'help'=>'Help',
    /*
     *
     * change band logo*/
    'manage_profile'=>'Manage Profile',
    'change_band_logo'=>'Change Band Logo',
    'change_logo'=>'Change Logo',
    'band_logo'=>'Band Logo',
    /*
     *
     * change band pass*/
    'current_password'=>'Current Password',
    'new_password'=>'New Password',
    'retype_password'=>'Retype Password',
    /*
     *
     * upload score*/
    'upload_score'=>'Upload Score',
    'track_file'=>'Track File',
    'add_detail'=>'Add Detail',
    /*
     * all albums*/
    'all_album'=>'All Albums',
    /*
     *
     * update album*/
    'update_album'=>'Update Album',
    'update_score'=>'Update Score',
    /*
     *
     * change publisher logo nad name*/
    'publisher_logo'=>'Publisher Logo',
    'name'=>'Name',
    /*
     *
     * publisher dashboard*/
    'dashboard'=>'Dashboard',
    'number_of_score'=>'Number Of Score',
    'number_of_album'=>'Number Of Album',
    'sales_album'=>'Sales Album',
    'album_user'=>'Album User',
    'latest_score'=>'Latest Score',
    'latest_album'=>'Latest Album',
    'latest_sales_score'=>'Latest Sales Score',
    'latest_sales_report'=>'Latest Sales Report',
    'score_title'=>'Score Title',
    'number_of_time_sales'=>'Number Of Time Sales',
    'new_score'=>'New Score',
    'new_album'=>'New Album',
    'new_sales_score'=>'New Sales Score',
    'view_all_score'=>'View All Score',
    'view_all_album'=>'View All Album',
    'view_all_sales_score'=>'View All Sales Score',
    'view_all_sales_report'=>'View All Sales Report',
);