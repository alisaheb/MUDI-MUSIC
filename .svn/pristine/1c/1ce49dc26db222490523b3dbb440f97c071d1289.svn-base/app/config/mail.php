<?php

return array(

	'driver' => 'smtp',
 
    'host' => 'smtp.gmail.com',
 
    'port' => 587,
 
    'from' => array('address' => 'alisaheb44@gmail.com', 'name' => 'Awesome Laravel 4 Auth App'),
 
    'encryption' => 'tls',
 
    'username' => 'alisaheb44@gmail.com',
 
    'password' => 'sefali563679832',
 
    'sendmail' => '/usr/sbin/sendmail -bs',
 
    'pretend' => false,
);
