<?php

class Profile extends \Eloquent {
	
}