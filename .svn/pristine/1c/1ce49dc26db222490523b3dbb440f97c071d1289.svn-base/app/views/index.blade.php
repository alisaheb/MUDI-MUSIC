We are in DASHBOARD
<a href="/logout">  Logout</a>
