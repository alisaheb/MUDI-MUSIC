<?php

/**
 * Created by PhpStorm.
 * User: ALi
 * Date: 20/09/2015
 * Time: 01:23
 */
class LanguageController extends \BaseController
{
public static function testLangeusge(){
    $path = app_path()."/controllers/language/dutch/dutch.json";
    $accessToken = file_get_contents($path);
    return $accessToken;
}

}